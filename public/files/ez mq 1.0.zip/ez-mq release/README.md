# ez-mq
 Auto login chrome extension for RabbitMQ pages (By Nathan Agcaoili)